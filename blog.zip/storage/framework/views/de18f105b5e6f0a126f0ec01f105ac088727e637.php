<?php /* C:\Users\user\Desktop\laravel\blog\resources\views/errors/permission.blade.php */ ?>
You have not permission